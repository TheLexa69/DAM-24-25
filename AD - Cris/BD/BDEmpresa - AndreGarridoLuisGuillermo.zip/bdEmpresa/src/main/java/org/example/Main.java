package org.example;

import org.example.Controller.HomeController;

public class Main {


    public static void main(String[] args) {
        HomeController hc = new HomeController();
        //EXERCICIO 2.1 (A) SQLEmpresa.java
        //-- -- hc.aumentarSalarios();

        //EXERCICIO 2.1 (B)
        //-- -- hc.nuevoDepartamento();

        //EXERCICIO 2.1 (C)
        //-- -- hc.borrarTrabajadorProyecto();


        //EXERCICIO 2.2
        //-- -- hc.listarTrabajadoresCiudad();


        //EXERCICIO 2.3
        //hc.actualizarDepartamento(); //(A)
        //hc.insertarProyecto(); //(B)
        //hc.borrarProyecto(); //(C)


        //Exercicio 2.4
        //hc.obtenerProxectosPorDepartamento(); //CONFIRMAR EN CLASE SI ESTA BIEN

        //Exercicio 2.5
        //hc.actualizarEmpleado(); //(A)
        //hc.obtenerDatosProyecto(); //(B)
        //hc.mostrarDepartamentosControlaProyectos(); //(C)
        //hc.mostrarNumeroEmpleadosEnDepartamento(); //(D)




        //Exercicio 2.6 //SQLResultSet.java
        //hc.mostrarTiposRS(); //(A)
        //hc.inserirObxectoProxecto(); //(B)
        //hc.incrementarSalarios(); //(C)
        //hc.infoEmpleadoCntdProyectos(); //(D)


        //Exercicio 3.1 //SQLMetaDatos
        //hc.mostrarInfoConexion();
        //hc.mostrarInfoTaboas(); //3.2 (A)
        //hc.mostrarInformacionColumnas(); //3.2 (B)
        //hc.mostrarInformacionProcedementos(); //3.2 (C)
        //hc.mostrarClavesPrimarias(); //3.2 (D)
        //hc.mostrarClavesForaneas(); //3.2 (E)

    }
}