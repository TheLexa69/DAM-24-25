package edu.badpals.sbconversion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbConversionApplication {

    public static void main(String[] args) {
        SpringApplication.run(SbConversionApplication.class, args);
    }

}
